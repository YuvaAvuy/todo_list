import os

class ToDoList:
    def __init__(self):
        self.tasks = []

    def add_task(self, task):
        self.tasks.append({"task": task, "completed": False})

    def view_tasks(self):
        if not self.tasks:
            print("\x1b[48;2;255;229;180mNo tasks found.\x1b[0m")
        else:
            for i, task in enumerate(self.tasks, 1):
                status = "\x1b[38;2;0;0;0m[X]\x1b[0m" if task["completed"] else "\x1b[38;2;0;0;0m[ ]\x1b[0m"
                print(f"{i}.{status} {task['task']}")

    def mark_completed(self, task_index):
        if 1 <= task_index <= len(self.tasks):
            self.tasks[task_index - 1]["completed"] = True
            print("\x1b[48;2;144;93;86mTask marked as completed.\x1b[0m")
        else:
            print("\x1b[48;2;255;0;0mInvalid task index.\x1b[0m")

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def main():
    todo_list = ToDoList()

    while True:
        clear_screen()

        print("\x1b[48;2;255;218;185mTo-Do List\x1b[0m")
        print("\x1b[48;2;192;192;192m1. Add Task\x1b[0m")
        print("\x1b[48;2;192;192;192m2. View Tasks\x1b[0m")
        print("\x1b[48;2;192;192;192m3. Mark Task as Completed\x1b[0m")
        print("\x1b[48;2;192;192;192m4. Exit\x1b[0m")

        choice = input("\x1b[48;2;255;218;185mEnter your choice (1-4): \x1b[0m")

        if choice == "1":
            task = input("\x1b[48;2;255;218;185mEnter the task: \x1b[0m")
            todo_list.add_task(task)
        elif choice == "2":
            todo_list.view_tasks()
        elif choice == "3":
            todo_list.view_tasks()
            task_index = int(input("\x1b[48;2;255;218;185mEnter the task index to mark as completed: \x1b[0m"))
            todo_list.mark_completed(task_index)
        elif choice == "4":
            print("\x1b[48;2;255;218;185mExiting...\x1b[0m")
            break
        else:
            print("\x1b[48;2;255;0;0mInvalid choice. Please enter a number between 1 and 4.\x1b[0m")

        input("\x1b[48;2;255;218;185mPress Enter to continue...\x1b[0m")

if __name__ == "__main__":
    main()
